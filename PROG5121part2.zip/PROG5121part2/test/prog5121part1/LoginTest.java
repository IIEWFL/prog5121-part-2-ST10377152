/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package prog5121part1;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author lab_services_student
 */
public class LoginTest {
    
    public LoginTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
       
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of checkUserName method, of class Login.
     */
    @Test
    public void testCheckUserName() {
        System.out.println("checkUserName");
        String username = "kyle!!!!!!";
        String example = "kyl_1";
        Login instance = new Login();
        boolean expResult = false;
        boolean exampleResult = true;
        boolean result = Login.checkUserName(username);
        boolean result2 = Login.checkUserName(example);
        assertEquals(expResult, result);
        assertEquals(exampleResult, result2);
        System.out.println(result);
        System.out.println(result2);
        
        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
    }

    /**
     * Test of checkPasswordComplexity method, of class Login.
     */
    @Test
    public void testCheckPasswordComplexity() {
        System.out.println("checkPasswordComplexity");
        String password = "Ch&&sec@ke99!";
        String example = "password";
        Login instance = new Login();
        boolean expResult = true;
        boolean exampleResult = false;
        boolean result = instance.checkPasswordComplexity(password);
        boolean result2 = instance.checkPasswordComplexity(example);
        assertEquals(expResult, result);
        assertEquals(exampleResult, result2);
        System.out.println(result);
        System.out.println(result2);
        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
    }

    /**
     * Test of registerUser method, of class Login.
     */
    @Test
    public void testRegisterUser() {
        System.out.println("registerUser");
        String username = "kyle!!!";
        String password = "Ch&&sec@ke99!";
        String firstName = "Kyle";
        String lastName = "Roberts";
        Login instance = new Login();
        String expResult = "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.";
        String result = instance.registerUser(username, password, firstName, lastName);
        assertEquals(expResult, result);
        System.out.println(result);
       
        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
    }

    /**
     * Test of loginUser method, of class Login.
     */
    @Test
    public void testLoginUser() {
        System.out.println("loginUser");
        String enteredUsername = "kyl_1";
        String enteredPassword = "Ch&&sec@ke99!";
        String storedUsername = "kyl_1";
        String storedPassword = "Ch&&sec@ke99!";
        Login instance = new Login();
        boolean expResult = true;
        boolean result = instance.loginUser(enteredUsername, enteredPassword, storedUsername, storedPassword);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
    }

    /**
     * Test of returnLoginStatus method, of class Login.
     */
    @Test
    public void testReturnLoginStatus() {
        System.out.println("returnLoginStatus");
        boolean loginStatus = true;
        String firstName = "Kyle";
        String lastName = "Roberts";
        Login instance = new Login();
        String expResult = "Welcome " + firstName + ", " + lastName + ", it is great to see you again.";
        String result = instance.returnLoginStatus(loginStatus, firstName, lastName);
        assertEquals(expResult, result);
        System.out.println(result);
        assertTrue(result.contains(result));
        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
    }
    
}
