package prog5121part1;
import javax.swing.JOptionPane;
import java.util.Scanner;

public class Account {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        Login login = new Login();

        System.out.println("Enter username:");
        String username = scanner.nextLine();
        while (!Login.checkUserName(username)) {
            System.out.print(Login.registerUser(username, username, username, username));
            System.out.println("Enter username:");
            username = scanner.nextLine();
        }
        System.out.println("Enter password:");
        String password = scanner.nextLine();
        while (!Login.checkPasswordComplexity(password)) {
            System.out.println(Login.registerUser(username, password, username, username));
            System.out.println("Enter password:");
            password = scanner.nextLine();

        }
        System.out.println("Enter first name:");
        String firstName = scanner.nextLine();

        System.out.println("Enter last name:");
        String lastName = scanner.nextLine();

        String registrationMessage = login.registerUser(username, password, firstName, lastName);
        System.out.println(registrationMessage);

        System.out.println("Enter username for login:");
        String loginUsername = scanner.nextLine();

        System.out.println("Enter password for login:");
        String loginPassword = scanner.nextLine();

        boolean loginStatus = login.loginUser(loginUsername, loginPassword, username, password);

        String loginStatusMessage = login.returnLoginStatus(loginStatus, firstName, lastName);
        System.out.println(loginStatusMessage);

    JOptionPane.showMessageDialog(null, "Welcome to EasyKanban");
    
     scanner.close();
     
    int choice;
        do {
            String input = JOptionPane.showInputDialog(null, "Choose an option:\n1. Add tasks\n2. Show report\n3. Quit");
            choice = Integer.parseInt(input);

            switch (choice) {
                case 1:
                    addTasks();
                    break;
                case 2:
                    JOptionPane.showMessageDialog(null, "Show report - Coming Soon");
                    break;
                case 3:
                    JOptionPane.showMessageDialog(null, "Quitting the application.");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice, please choose again.");
            }
        } while (choice != 3);
    }

    private static void addTasks() {
        int numTasks = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter number of tasks:"));

        Task[] tasks = new Task[numTasks];

        for (int i = 0; i < numTasks; i++) {
            Task task = new Task();
            task.setTaskName(JOptionPane.showInputDialog(null, "Enter task name:"));
            while (!task.checkTaskDescription()) {
                JOptionPane.showMessageDialog(null, "Task description should not be more than 50 characters.");
                task.setTaskDescription(JOptionPane.showInputDialog(null, "Enter task description:"));
            }
            task.setDeveloperDetails(JOptionPane.showInputDialog(null, "Enter developer details:"));
            task.setTaskDuration(Integer.parseInt(JOptionPane.showInputDialog(null, "Enter task duration in hours:")));
            task.setTaskID(task.createTaskID());
            task.setTaskStatus(JOptionPane.showInputDialog(null, "Enter task status (To Do, Done, Doing):"));

            tasks[i] = task;

            JOptionPane.showMessageDialog(null, task.printTaskDetails());
        }

        int totalHours = calculateTotalHours(tasks);
        JOptionPane.showMessageDialog(null, "Total hours across all tasks: " + totalHours);
    }

    private static int calculateTotalHours(Task[] tasks) {
        int totalHours = 0;
        for (Task task : tasks) {
            totalHours += task.getTaskDuration(); 
        }
        return totalHours;
    }
}



    /*  public static String registerUser(String username, String password){
    
        
        boolean userNameValid = false;
        
        if(!userNameValid){
        return "Username invalid";
        }
        
        boolean passwordComplex = false;
        
        if(!passwordComplex){
        return "Password incorrect";
        }
        return "User register success";
    }*/

//refferences
//https://stackoverflow.com/questions/33140900/simple-login-with-java-code-using-conditional-assignment
//https://www.shecodes.io/athena/39971-how-to-create-login-and-registration-code-in-java