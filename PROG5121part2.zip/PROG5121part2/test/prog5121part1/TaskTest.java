package prog5121part1;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class TaskTest {

    private Task task1;
    private Task task2;
    private Task task3;
    private Task task4;
    private Task task5;

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
        task1 = new Task();
        task1.setTaskName("Login Feature");
        task1.setTaskDescription("Create Login to authenticate users");
        task1.setDeveloperDetails("Robyn Harrison");
        task1.setTaskDuration(8);
        task1.setTaskID(task1.createTaskID());
        task1.setTaskStatus("To Do");

        task2 = new Task();
        task2.setTaskName("Add Task Feature");
        task2.setTaskDescription("Create Add Task feature to add task users");
        task2.setDeveloperDetails("Mike Smith");
        task2.setTaskDuration(10);
        task2.setTaskID(task2.createTaskID());
        task2.setTaskStatus("Doing");

        
        task3 = new Task();
        task3.setTaskName("Create Report");
        task3.setTaskDescription("Create report for management");
        task3.setDeveloperDetails("Michael Armstrong");
        task3.setTaskDuration(12);
        task3.setTaskID(task3.createTaskID());
        task3.setTaskStatus("Done");

        task4 = new Task();
        task4.setTaskName("Test Hardware");
        task4.setTaskDescription("Test the new hardware installations");
        task4.setDeveloperDetails("Jonathan Thatcher");
        task4.setTaskDuration(55);
        task4.setTaskID(task4.createTaskID());
        task4.setTaskStatus("To Do");

        task5 = new Task();
        task5.setTaskName("Network Deployment");
        task5.setTaskDescription("Deploy the new network configurations");
        task5.setDeveloperDetails("Sandra Ng");
        task5.setTaskDuration(11);
        task5.setTaskID(task5.createTaskID());
        task5.setTaskStatus("Doing");
    }

    @After
    public void tearDown() {
    }

    @Test
    public void testSetTaskName() {
        assertEquals("Login Feature", task1.getTaskName());
        assertEquals("Add Task Feature", task2.getTaskName());
    }

    @Test
    public void testCheckTaskDescription() {
       
        task1.setTaskDescription("Valid description");
        assertTrue(task1.checkTaskDescription());

       
        task1.setTaskDescription("This description is intentionally made longer than fifty characters to test the validation logic.");
        assertFalse(task1.checkTaskDescription());
    }

    @Test
    public void testSetTaskDescription() {
        task1.setTaskDescription("Create Login to authenticate users");
        assertEquals("Create Login to authenticate users", task1.getTaskDescription());

        task2.setTaskDescription("Create Add Task feature to add task users");
        assertEquals("Create Add Task feature to add task users", task2.getTaskDescription());
    }

    @Test
    public void testSetDeveloperDetails() {
        task1.setDeveloperDetails("Robyn Harrison");
        assertEquals("Robyn Harrison", task1.getDeveloperDetails());

        task2.setDeveloperDetails("Mike Smith");
        assertEquals("Mike Smith", task2.getDeveloperDetails());
    }

    @Test
    public void testSetTaskDuration() {
        task1.setTaskDuration(8);
        assertEquals(8, task1.getTaskDuration());

        task2.setTaskDuration(10);
        assertEquals(10, task2.getTaskDuration());
    }

    @Test
    public void testSetTaskID() {
        task1.setTaskID(task1.createTaskID());
        assertNotNull(task1.getTaskID());

        task2.setTaskID(task2.createTaskID());
        assertNotNull(task2.getTaskID());
    }

    @Test
    public void testSetTaskStatus() {
        task1.setTaskStatus("To Do");
        assertEquals("To Do", task1.getTaskStatus());

        task2.setTaskStatus("Doing");
        assertEquals("Doing", task2.getTaskStatus());
    }

    @Test
    public void testCreateTaskID() {
        assertEquals("LO:0:SON", task1.createTaskID());  
        assertEquals("AD:1:ITH", task2.createTaskID());  
    }

    @Test
    public void testPrintTaskDetails() {
        String expectedDetails1 = "Task Status: To Do\nDeveloper Details: Robyn Harrison\nTask Number: 0\nTask Name: Login Feature\nTask Description: Create Login to authenticate users\nTask ID: LO:0:SON\nDuration: 8 hours";
        assertEquals(expectedDetails1, task1.printTaskDetails());

        String expectedDetails2 = "Task Status: Doing\nDeveloper Details: Mike Smith\nTask Number: 1\nTask Name: Add Task Feature\nTask Description: Create Add Task feature to add task users\nTask ID: AD:1:ITH\nDuration: 10 hours";
        assertEquals(expectedDetails2, task2.printTaskDetails());
    }

    @Test
    public void testReturnTotalHours() {
        assertEquals(8, task1.returnTotalHours());
        assertEquals(10, task2.returnTotalHours());
    }

    @Test
    public void testGetTaskNumber() {
        assertEquals(2, Task.getTaskNumber());
    }

    @Test
    public void testGetTaskDuration() {
        assertEquals(8, task1.getTaskDuration());
        assertEquals(10, task2.getTaskDuration());
    }

    @Test
    public void testTotalHoursInLoop() {
        Task[] tasks = {task1, task2};
        int totalHours = 0;

        for (Task task : tasks) {
            totalHours += task.returnTotalHours();
        }
        assertEquals(18, totalHours);  
    }

    @Test
    public void testAdditionalDataTotalHours() {
        Task[] tasks = {task1, task2, task3, task4, task5};
        int totalHours = 0;

        for (Task task : tasks) {
            totalHours += task.returnTotalHours();
        }
        assertEquals(96, totalHours);  
    }
}
